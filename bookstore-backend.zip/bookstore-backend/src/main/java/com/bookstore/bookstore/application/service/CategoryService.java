package com.bookstore.bookstore.application.service;

import com.bookstore.bookstore.application.command.CreateCategoryCommand;
import com.bookstore.bookstore.application.command.DeleteCategoryCommand;
import com.bookstore.bookstore.application.command.UpdateCategoryCommand;
import com.bookstore.bookstore.application.exception.ApplicationErrorCode;
import com.bookstore.bookstore.application.exception.ApplicationException;
import com.bookstore.bookstore.application.port.in.ICategoryService;
import com.bookstore.bookstore.application.port.out.ICategoryRepository;
import com.bookstore.bookstore.domain.model.Category;
import com.bookstore.bookstore.shared.util.StringUtils;
import java.time.Instant;
import java.util.List;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class CategoryService implements ICategoryService {

    private final ICategoryRepository categoryRepository;

    @Override
    public List<Category> getAll() {
        return categoryRepository.findAll();
    }

    @Override
    public Category getById(UUID categoryId) {
        if (categoryId == null) {
            throw new ApplicationException(ApplicationErrorCode.INVALID_ARGUMENT, "categoryId");
        }

        Category currentCategory = categoryRepository.findById(categoryId)
                .orElseThrow(() -> new ApplicationException(ApplicationErrorCode.CATEGORY_NOT_FOUND));

        if (currentCategory.getDeletedAt() != null) {
            throw new ApplicationException(ApplicationErrorCode.CATEGORY_NOT_FOUND);
        }

        return currentCategory;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Category create(CreateCategoryCommand command) {
        if (command == null) {
            throw new ApplicationException(ApplicationErrorCode.INVALID_ARGUMENT, "command");
        }

        String name = StringUtils.trimToNull(command.name());
        String description = StringUtils.trimToNull(command.description());

        if (categoryRepository.existsByName(name)) {
            throw new ApplicationException(ApplicationErrorCode.CATEGORY_NAME_ALREADY_EXISTS);
        }

        Instant now = Instant.now();
        Category category = new Category(
                UUID.randomUUID(),
                name,
                description,
                now,
                now,
                null
        );

        return categoryRepository.save(category);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Category update(UpdateCategoryCommand command) {
        if (command == null) {
            throw new ApplicationException(ApplicationErrorCode.INVALID_ARGUMENT, "command");
        }

        Category currentCategory = categoryRepository.findById(command.categoryId())
                .orElseThrow(() -> new ApplicationException(ApplicationErrorCode.CATEGORY_NOT_FOUND));

        String name = StringUtils.trimToNull(command.name());
        String description = StringUtils.trimToNull(command.description());

        if (!currentCategory.getName().equals(name) && categoryRepository.existsByName(name)) {
            throw new ApplicationException(ApplicationErrorCode.CATEGORY_NAME_ALREADY_EXISTS);
        }

        currentCategory.updateCategory(name, description);
        return categoryRepository.save(currentCategory);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void delete(DeleteCategoryCommand command) {
        if (command == null) {
            throw new ApplicationException(ApplicationErrorCode.INVALID_ARGUMENT, "command");
        }

        Category currentCategory = categoryRepository.findById(command.categoryId())
                .orElseThrow(() -> new ApplicationException(ApplicationErrorCode.CATEGORY_NOT_FOUND));

        currentCategory.softDelete();
        categoryRepository.save(currentCategory);
    }
}
