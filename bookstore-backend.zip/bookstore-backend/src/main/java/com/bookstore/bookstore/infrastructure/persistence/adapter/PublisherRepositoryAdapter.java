package com.bookstore.bookstore.infrastructure.persistence.adapter;

import com.bookstore.bookstore.application.port.out.IPublisherRepository;
import com.bookstore.bookstore.domain.model.Publisher;
import com.bookstore.bookstore.infrastructure.persistence.entity.PublisherJpaEntity;
import com.bookstore.bookstore.infrastructure.persistence.mapper.PublisherPersistenceMapper;
import com.bookstore.bookstore.infrastructure.persistence.repository.PublisherJpaRepository;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;

@Repository
@RequiredArgsConstructor
public class PublisherRepositoryAdapter implements IPublisherRepository {

    private final PublisherJpaRepository publisherJpaRepository;
    private final PublisherPersistenceMapper publisherPersistenceMapper;

    @Override
    public List<Publisher> findAll() {
        return publisherJpaRepository.findAllByDeletedAtIsNull().stream()
                .map(publisherPersistenceMapper::toDomain)
                .toList();
    }

    @Override
    public Optional<Publisher> findById(UUID publisherId) {
        return publisherJpaRepository.findById(publisherId)
                .map(publisherPersistenceMapper::toDomain);
    }

    @Override
    public Optional<Publisher> findByName(String publisherName) {
        return publisherJpaRepository.findByNameAndDeletedAtIsNull(publisherName)
                .map(publisherPersistenceMapper::toDomain);
    }

    @Override
    public boolean existsById(UUID publisherId) {
        return publisherJpaRepository.existsById(publisherId);
    }

    @Override
    public boolean existsByName(String publisherName) {
        return publisherJpaRepository.existsByNameAndDeletedAtIsNull(publisherName);
    }

    @Override
    public Publisher save(Publisher publisher) {
        PublisherJpaEntity entity = publisherJpaRepository.findById(publisher.getId())
                .orElseGet(PublisherJpaEntity::new);
        publisherPersistenceMapper.copyToEntity(entity, publisher);
        return publisherPersistenceMapper.toDomain(publisherJpaRepository.save(entity));
    }

    @Override
    public void deleteById(UUID publisherId) {
        publisherJpaRepository.deleteById(publisherId);
    }
}
