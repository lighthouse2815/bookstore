package com.bookstore.bookstore.infrastructure.persistence.adapter;

import com.bookstore.bookstore.application.port.out.IBookRepository;
import com.bookstore.bookstore.domain.model.Book;
import com.bookstore.bookstore.infrastructure.persistence.entity.BookJpaEntity;
import com.bookstore.bookstore.infrastructure.persistence.mapper.BookPersistenceMapper;
import com.bookstore.bookstore.infrastructure.persistence.repository.BookJpaRepository;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;

@Repository
@RequiredArgsConstructor
public class BookRepositoryAdapter implements IBookRepository {

    private final BookJpaRepository bookJpaRepository;
    private final BookPersistenceMapper bookPersistenceMapper;

    @Override
    public List<Book> findAll() {
        return bookJpaRepository.findAllByDeletedAtIsNull().stream()
                .map(bookPersistenceMapper::toDomain)
                .toList();
    }

    @Override
    public Optional<Book> findById(UUID bookId) {
        return bookJpaRepository.findById(bookId)
                .map(bookPersistenceMapper::toDomain);
    }

    @Override
    public List<Book> searchByKeyword(String keyword) {
        return bookJpaRepository.searchByKeyword(keyword).stream()
                .map(bookPersistenceMapper::toDomain)
                .toList();
    }

    @Override
    public Book save(Book book) {
        BookJpaEntity entity = bookJpaRepository.findById(book.getId())
                .orElseGet(BookJpaEntity::new);
        bookPersistenceMapper.copyToEntity(entity, book);
        return bookPersistenceMapper.toDomain(bookJpaRepository.save(entity));
    }

    @Override
    public void deleteById(UUID bookId) {
        bookJpaRepository.deleteById(bookId);
    }
}
