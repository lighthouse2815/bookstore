package com.bookstore.bookstore.application.port.in;

import com.bookstore.bookstore.application.command.CreateAuthorCommand;
import com.bookstore.bookstore.application.command.DeleteAuthorCommand;
import com.bookstore.bookstore.application.command.UpdateAuthorCommand;
import com.bookstore.bookstore.domain.model.Author;
import java.util.List;
import java.util.UUID;

public interface IAuthorService {

    List<Author> getAll();

    Author getById(UUID authorId);

    Author create(CreateAuthorCommand command);

    Author update(UpdateAuthorCommand command);

    void delete(DeleteAuthorCommand command);
}
