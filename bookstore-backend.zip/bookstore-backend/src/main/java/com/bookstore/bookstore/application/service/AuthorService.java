package com.bookstore.bookstore.application.service;

import com.bookstore.bookstore.application.command.CreateAuthorCommand;
import com.bookstore.bookstore.application.command.DeleteAuthorCommand;
import com.bookstore.bookstore.application.command.UpdateAuthorCommand;
import com.bookstore.bookstore.application.exception.ApplicationErrorCode;
import com.bookstore.bookstore.application.exception.ApplicationException;
import com.bookstore.bookstore.application.port.in.IAuthorService;
import com.bookstore.bookstore.application.port.out.IAuthorRepository;
import com.bookstore.bookstore.domain.model.Author;
import com.bookstore.bookstore.shared.util.StringUtils;
import java.time.Instant;
import java.util.List;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class AuthorService implements IAuthorService {

    private final IAuthorRepository authorRepository;

    @Override
    public List<Author> getAll() {
        return authorRepository.findAll();
    }

    @Override
    public Author getById(UUID authorId) {
        if (authorId == null) {
            throw new ApplicationException(ApplicationErrorCode.INVALID_ARGUMENT, "authorId");
        }

        Author currentAuthor = authorRepository.findById(authorId)
                .orElseThrow(() -> new ApplicationException(ApplicationErrorCode.AUTHOR_NOT_FOUND));

        if (currentAuthor.getDeletedAt() != null) {
            throw new ApplicationException(ApplicationErrorCode.AUTHOR_NOT_FOUND);
        }

        return currentAuthor;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Author create(CreateAuthorCommand command) {
        if (command == null) {
            throw new ApplicationException(ApplicationErrorCode.INVALID_ARGUMENT, "command");
        }

        String name = StringUtils.trimToNull(command.name());
        String biography = StringUtils.trimToNull(command.biography());

        if (authorRepository.existsByName(name)) {
            throw new ApplicationException(ApplicationErrorCode.AUTHOR_NAME_ALREADY_EXISTS);
        }

        Instant now = Instant.now();
        Author author = new Author(
                UUID.randomUUID(),
                name,
                biography,
                now,
                now,
                null
        );

        return authorRepository.save(author);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Author update(UpdateAuthorCommand command) {
        if (command == null) {
            throw new ApplicationException(ApplicationErrorCode.INVALID_ARGUMENT, "command");
        }

        Author currentAuthor = authorRepository.findById(command.authorId())
                .orElseThrow(() -> new ApplicationException(ApplicationErrorCode.AUTHOR_NOT_FOUND));

        String name = StringUtils.trimToNull(command.name());
        String biography = StringUtils.trimToNull(command.biography());

        if (!currentAuthor.getName().equals(name) && authorRepository.existsByName(name)) {
            throw new ApplicationException(ApplicationErrorCode.AUTHOR_NAME_ALREADY_EXISTS);
        }

        currentAuthor.updateAuthor(name, biography);
        return authorRepository.save(currentAuthor);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void delete(DeleteAuthorCommand command) {
        if (command == null) {
            throw new ApplicationException(ApplicationErrorCode.INVALID_ARGUMENT, "command");
        }

        Author currentAuthor = authorRepository.findById(command.authorId())
                .orElseThrow(() -> new ApplicationException(ApplicationErrorCode.AUTHOR_NOT_FOUND));

        currentAuthor.softDelete();
        authorRepository.save(currentAuthor);
    }
}
