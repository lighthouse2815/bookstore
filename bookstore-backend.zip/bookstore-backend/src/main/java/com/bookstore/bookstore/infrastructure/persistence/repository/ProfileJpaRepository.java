package com.bookstore.bookstore.infrastructure.persistence.repository;

import com.bookstore.bookstore.infrastructure.persistence.entity.ProfileJpaEntity;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProfileJpaRepository extends JpaRepository<ProfileJpaEntity, UUID> {

    @EntityGraph(attributePaths = "user")
    List<ProfileJpaEntity> findAllByDeletedAtIsNull();

    @Override
    @EntityGraph(attributePaths = "user")
    Optional<ProfileJpaEntity> findById(UUID profileId);

    @EntityGraph(attributePaths = "user")
    Optional<ProfileJpaEntity> findByUser_Id(UUID userId);

    boolean existsByUser_Id(UUID userId);
}
