package com.bookstore.bookstore.infrastructure.persistence.adapter;

import com.bookstore.bookstore.application.port.out.IProfileRepository;
import com.bookstore.bookstore.domain.model.Profile;
import com.bookstore.bookstore.infrastructure.persistence.entity.ProfileJpaEntity;
import com.bookstore.bookstore.infrastructure.persistence.entity.UserJpaEntity;
import com.bookstore.bookstore.infrastructure.persistence.mapper.ProfilePersistenceMapper;
import com.bookstore.bookstore.infrastructure.persistence.repository.ProfileJpaRepository;
import com.bookstore.bookstore.infrastructure.persistence.repository.UserJpaRepository;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;

@Repository
@RequiredArgsConstructor
public class ProfileRepositoryAdapter implements IProfileRepository {

    private final ProfileJpaRepository profileJpaRepository;
    private final UserJpaRepository userJpaRepository;
    private final ProfilePersistenceMapper profilePersistenceMapper;

    @Override
    public List<Profile> findAll() {
        return profileJpaRepository.findAllByDeletedAtIsNull().stream()
                .map(profilePersistenceMapper::toDomain)
                .toList();
    }

    @Override
    public Optional<Profile> findById(UUID profileId) {
        return profileJpaRepository.findById(profileId)
                .map(profilePersistenceMapper::toDomain);
    }

    @Override
    public Optional<Profile> findByUserId(UUID userId) {
        return profileJpaRepository.findByUser_Id(userId)
                .map(profilePersistenceMapper::toDomain);
    }

    @Override
    public boolean existsById(UUID profileId) {
        return profileJpaRepository.existsById(profileId);
    }

    @Override
    public boolean existsByUserId(UUID userId) {
        return profileJpaRepository.existsByUser_Id(userId);
    }

    @Override
    public void deleteById(UUID profileId) {
        profileJpaRepository.deleteById(profileId);
    }

    @Override
    public Profile save(Profile profile) {
        ProfileJpaEntity entity = profileJpaRepository.findById(profile.getId())
                .orElseGet(ProfileJpaEntity::new);
        UserJpaEntity user = userJpaRepository.getReferenceById(profile.getUserId());
        profilePersistenceMapper.copyToEntity(profile, entity, user);
        return profilePersistenceMapper.toDomain(profileJpaRepository.save(entity));
    }
}
