package com.bookstore.bookstore.presentation.response;

import java.time.Instant;
import java.util.UUID;

public record PublisherResponse(
        UUID id,
        String name,
        String description,
        Instant createdAt,
        Instant updatedAt
) {
}
