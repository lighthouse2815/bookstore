package com.bookstore.bookstore.application.port.in;

import com.bookstore.bookstore.application.command.UpdatePermissionCommand;
import com.bookstore.bookstore.domain.model.Permission;
import java.util.List;
import java.util.UUID;

public interface IPermissionService {

    List<Permission> getAll();

    Permission getById(UUID permissionId);

    Permission update(UpdatePermissionCommand command);

}
