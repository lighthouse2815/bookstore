package com.bookstore.bookstore.infrastructure.persistence.adapter;

import com.bookstore.bookstore.application.port.out.IRoleRepository;
import com.bookstore.bookstore.domain.enums.PermissionCode;
import com.bookstore.bookstore.domain.model.Permission;
import com.bookstore.bookstore.domain.model.Role;
import com.bookstore.bookstore.infrastructure.persistence.entity.PermissionJpaEntity;
import com.bookstore.bookstore.infrastructure.persistence.entity.RoleJpaEntity;
import com.bookstore.bookstore.infrastructure.persistence.mapper.RolePersistenceMapper;
import com.bookstore.bookstore.infrastructure.persistence.repository.PermissionJpaRepository;
import com.bookstore.bookstore.infrastructure.persistence.repository.RoleJpaRepository;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;

@Repository
@RequiredArgsConstructor
public class RoleRepositoryAdapter implements IRoleRepository {

    private final RoleJpaRepository roleJpaRepository;
    private final PermissionJpaRepository permissionJpaRepository;
    private final RolePersistenceMapper rolePersistenceMapper;

    @Override
    public List<Role> findAll() {
        return roleJpaRepository.findAllByDeletedAtIsNull().stream()
                .map(rolePersistenceMapper::toDomain)
                .toList();
    }

    @Override
    public Optional<Role> findById(UUID roleId) {
        return roleJpaRepository.findById(roleId)
                .map(rolePersistenceMapper::toDomain);
    }

    @Override
    public Optional<Role> findByName(String roleName) {
        return roleJpaRepository.findByNameAndDeletedAtIsNull(roleName)
                .map(rolePersistenceMapper::toDomain);
    }

    @Override
    public boolean existsById(UUID roleId) {
        return roleJpaRepository.existsById(roleId);
    }

    @Override
    public boolean existsByName(String roleName) {
        return roleJpaRepository.existsByName(roleName);
    }

    @Override
    public boolean existsByPermissionCode(PermissionCode permissionCode) {
        return roleJpaRepository.existsByPermissionsCode(permissionCode);
    }

    @Override
    public Role save(Role role) {
        RoleJpaEntity entity = roleJpaRepository.findById(role.getId())
                .orElseGet(RoleJpaEntity::new);
        rolePersistenceMapper.copyToEntity(role, entity, resolvePermissions(role.getPermissions()));
        return rolePersistenceMapper.toDomain(roleJpaRepository.save(entity));
    }

    @Override
    public void deleteById(UUID roleId) {
        roleJpaRepository.deleteById(roleId);
    }

    private Set<PermissionJpaEntity> resolvePermissions(Set<Permission> permissions) {
        Set<PermissionJpaEntity> resolved = new LinkedHashSet<>();
        for (Permission permission : permissions) {
            PermissionJpaEntity entity = permissionJpaRepository.findById(permission.getId())
                    .orElseThrow(() -> new IllegalStateException("Permission not found: " + permission.getId()));
            resolved.add(entity);
        }
        return resolved;
    }
}
