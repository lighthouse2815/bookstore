package com.bookstore.bookstore.infrastructure.persistence.repository;

import com.bookstore.bookstore.domain.enums.PermissionCode;
import com.bookstore.bookstore.infrastructure.persistence.entity.RoleJpaEntity;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleJpaRepository extends JpaRepository<RoleJpaEntity, UUID> {

    @EntityGraph(attributePaths = "permissions")
    List<RoleJpaEntity> findAllByDeletedAtIsNull();

    @Override
    @EntityGraph(attributePaths = "permissions")
    Optional<RoleJpaEntity> findById(UUID roleId);

    @EntityGraph(attributePaths = "permissions")
    Optional<RoleJpaEntity> findByName(String roleName);

    @EntityGraph(attributePaths = "permissions")
    Optional<RoleJpaEntity> findByNameAndDeletedAtIsNull(String roleName);

    boolean existsByName(String roleName);

    boolean existsByPermissionsCode(PermissionCode permissionCode);
}
