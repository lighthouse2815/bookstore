package com.bookstore.bookstore.infrastructure.persistence.adapter;

import com.bookstore.bookstore.application.port.out.IAuthorRepository;
import com.bookstore.bookstore.domain.model.Author;
import com.bookstore.bookstore.infrastructure.persistence.entity.AuthorJpaEntity;
import com.bookstore.bookstore.infrastructure.persistence.mapper.AuthorPersistenceMapper;
import com.bookstore.bookstore.infrastructure.persistence.repository.AuthorJpaRepository;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;

@Repository
@RequiredArgsConstructor
public class AuthorRepositoryAdapter implements IAuthorRepository {

    private final AuthorJpaRepository authorJpaRepository;
    private final AuthorPersistenceMapper authorPersistenceMapper;

    @Override
    public List<Author> findAll() {
        return authorJpaRepository.findAllByDeletedAtIsNull().stream()
                .map(authorPersistenceMapper::toDomain)
                .toList();
    }

    @Override
    public Optional<Author> findById(UUID authorId) {
        return authorJpaRepository.findById(authorId)
                .map(authorPersistenceMapper::toDomain);
    }

    @Override
    public Optional<Author> findByName(String authorName) {
        return authorJpaRepository.findByNameAndDeletedAtIsNull(authorName)
                .map(authorPersistenceMapper::toDomain);
    }

    @Override
    public boolean existsById(UUID authorId) {
        return authorJpaRepository.existsById(authorId);
    }

    @Override
    public boolean existsByName(String authorName) {
        return authorJpaRepository.existsByNameAndDeletedAtIsNull(authorName);
    }

    @Override
    public Author save(Author author) {
        AuthorJpaEntity entity = authorJpaRepository.findById(author.getId())
                .orElseGet(AuthorJpaEntity::new);
        authorPersistenceMapper.copyToEntity(entity, author);
        return authorPersistenceMapper.toDomain(authorJpaRepository.save(entity));
    }

    @Override
    public void deleteById(UUID authorId) {
        authorJpaRepository.deleteById(authorId);
    }
}
